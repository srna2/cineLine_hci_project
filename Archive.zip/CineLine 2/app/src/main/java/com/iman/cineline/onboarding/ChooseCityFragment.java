package com.iman.cineline.onboarding;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.iman.cineline.R;

public class ChooseCityFragment extends Fragment {

    private static final String PREF_SELECTED_CITY = "selected_city";

    private SharedPreferences sharedPreferences;
    private View selectedCityTextView;
    private int defaultTextColor;
    private int selectedColor = Color.parseColor("#A60202");

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_choose_city, container, false);

        sharedPreferences = requireContext().getSharedPreferences("MoviePrefs", 0);
        defaultTextColor = getResources().getColor(R.color.black);

        View city1TextView = view.findViewById(R.id.city1);
        View city2TextView = view.findViewById(R.id.city2);
        View city3TextView = view.findViewById(R.id.city3);
        View city4TextView = view.findViewById(R.id.city4);

        city1TextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectCity(city1TextView, "Sarajevo");
            }
        });

        city2TextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectCity(city2TextView, "Mostar");
            }
        });

        city3TextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectCity(city3TextView, "Banja Luka");
            }
        });

        city4TextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectCity(city4TextView, "Zenica");
            }
        });

        View continueTextView = view.findViewById(R.id.button2);
        continueTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToMovieSelectionFragment();
            }
        });

        return view;
    }

    private void selectCity(View cityTextView, String cityName) {
        // Reset the previous selected view if any
        if (selectedCityTextView != null) {
            selectedCityTextView.setBackgroundColor(Color.WHITE);
        }

        // Set the new selected view
        cityTextView.setBackgroundColor(selectedColor);
        selectedCityTextView = cityTextView;

        saveSelectedCity(cityName);
    }

    private void saveSelectedCity(String city) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(PREF_SELECTED_CITY, city);
        editor.apply();
    }

    private void navigateToMovieSelectionFragment() {
        NavHostFragment.findNavController(this)
                .navigate(R.id.action_chooseCityFragment_to_movieSelectionFragment);
    }
}