package com.iman.cineline.home;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.iman.cineline.R;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class MoviePaymentFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_movie_payment, container, false);

        LocalDate currentDate = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd");
        String formattedDate = currentDate.format(formatter);
        TextView date = view.findViewById(R.id.date);
        date.setText(formattedDate);

        // Retrieve data from shared preferences
        SharedPreferences sharedPreferences = requireContext().getSharedPreferences("MoviePrefs", Context.MODE_PRIVATE);
        String movieName = sharedPreferences.getString("title", "");
        String description = sharedPreferences.getString("opis", "");
        String imageUrl = sharedPreferences.getString("imageUrl", "");
        String zanr = sharedPreferences.getString("type", "");

        // Set data to the views
        ImageView imageView = view.findViewById(R.id.image);
        TextView titleTextView = view.findViewById(R.id.title);
        TextView descriptionTextView = view.findViewById(R.id.description);
        TextView zanrText = view.findViewById(R.id.zanr_text);
        zanrText.setText(zanr);
        titleTextView.setText(movieName);
        descriptionTextView.setText(description);

        Glide.with(this)
                .load(imageUrl)// Add a placeholder image if desired
                .placeholder(R.drawable.movie_ticket)
                .into(imageView);

        // MasterCard ConstraintLayout
        ConstraintLayout masterCardLayout = view.findViewById(R.id.mastercard);
        masterCardLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Save selected payment method to shared preferences
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("paymentMethod", "MasterCard");
                editor.apply();

                navigateToPaymentDetailsFragment();
            }
        });

        // PayPal ConstraintLayout
        ConstraintLayout paypalLayout = view.findViewById(R.id.paypal);
        paypalLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Save selected payment method to shared preferences
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("paymentMethod", "PayPal");
                editor.apply();

                navigateToPaymentDetailsFragment();
            }
        });

        return view;
    }

    private void navigateToPaymentDetailsFragment() {
        // Retrieve the NavController
        NavController navController = NavHostFragment.findNavController(this);

        // Navigate to the payment details fragment using the action
        navController.navigate(R.id.action_moviePaymentFragment_to_paymentDetailsFragment);
    }
}