package com.iman.cineline.payment;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.iman.cineline.R;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class PaymentDetailsFragment extends Fragment {


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_payment_details, container, false);

        SharedPreferences sharedPreferences = requireContext().getSharedPreferences("MoviePrefs", Context.MODE_PRIVATE);
        String imageUrl = sharedPreferences.getString("imageUrl", "");
        ImageView imageView = view.findViewById(R.id.image);

        Glide.with(this)
                .load(imageUrl)// Add a placeholder image if desired
                .placeholder(R.drawable.movie_ticket)
                .into(imageView);

        LocalDate currentDate = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd");
        String formattedDate = currentDate.format(formatter);
        TextView date = view.findViewById(R.id.date);
        date.setText(formattedDate);

        Button nastaviButton = view.findViewById(R.id.nastavi);
        nastaviButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToMovieSelectionFragment();
            }
        });

        return view;
    }

    private void navigateToMovieSelectionFragment() {
        // Retrieve the NavController
        NavController navController = NavHostFragment.findNavController(this);

        // Navigate to the movie selection fragment using the action
        navController.navigate(R.id.action_paymentDetailsFragment_to_movieSelectionFragment);
    }
}