package com.iman.cineline.home;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.iman.cineline.R;

import org.w3c.dom.Text;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class MovieDetailsFragment extends Fragment {

    private SharedPreferences sharedPreferences;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_movie_details, container, false);

        LocalDate currentDate = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd");
        String formattedDate = currentDate.format(formatter);
        TextView date = view.findViewById(R.id.date);
        date.setText(formattedDate);

        // Get the movie details from SharedPreferences
        sharedPreferences = requireContext().getSharedPreferences("MoviePrefs", Context.MODE_PRIVATE);
        String title = sharedPreferences.getString("title", "");
        String opis = sharedPreferences.getString("opis", "");
        String imageUrl = sharedPreferences.getString("imageUrl", "");
        String redatelj = sharedPreferences.getString("redatelj", "");
        String trajanje = sharedPreferences.getString("trajanje", "");
        String godina = sharedPreferences.getString("pocetak","");
        String zanr = sharedPreferences.getString("type","");

        // Display the movie details in the fragment layout
        ImageView imageView = view.findViewById(R.id.image);
        TextView titleTextView = view.findViewById(R.id.title);
        TextView descriptionTextView = view.findViewById(R.id.description);
        TextView redateljView = view.findViewById(R.id.redatelj_text);
        TextView trajanjeView = view.findViewById(R.id.trajanje_text);
        TextView godinaView = view.findViewById(R.id.godina_text);
        TextView movie_type = view.findViewById(R.id.movie_type);

        // Load the image using Glide
        Glide.with(this)
                .load(imageUrl) // Add a placeholder image if desired
                .placeholder(R.drawable.movie_ticket)
                .into(imageView);

        titleTextView.setText(title);
        descriptionTextView.setText(opis);
        redateljView.setText(redatelj);
        trajanjeView.setText(trajanje);
        godinaView.setText(godina);
        movie_type.setText(zanr);

        Button time1Button = view.findViewById(R.id.time1);
        Button time2Button = view.findViewById(R.id.time2);
        Button time3Button = view.findViewById(R.id.time3);

        time1Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveSelectedTime("15:30");
                navigateToMovieChooseSeatFragment();
            }
        });

        time2Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveSelectedTime("18:00");
                navigateToMovieChooseSeatFragment();
            }
        });

        time3Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveSelectedTime("21:00");
                navigateToMovieChooseSeatFragment();
            }
        });

        return view;
    }

    private void saveSelectedTime(String time) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("selectedTime", time);
        editor.apply();
    }

    private void navigateToMovieChooseSeatFragment() {
        NavController navController = NavHostFragment.findNavController(this);
        navController.navigate(R.id.action_movieDetailsFragment_to_movieChooseSeatFragment);
    }
}
