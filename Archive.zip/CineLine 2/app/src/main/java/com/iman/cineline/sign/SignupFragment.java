package com.iman.cineline.sign;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.iman.cineline.R;

public class SignupFragment extends Fragment {


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_signup, container, false);


        View getStartedButton = view.findViewById(R.id.get_started);
        View signup = view.findViewById(R.id.googleorapple);
        View signin = view.findViewById(R.id.signin);
        getStartedButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToHome();
            }
        });
        signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToSignin();
            }
        });
        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToGoogle();
            }
        });

        return view;
    }

    private void navigateToGoogle() {
        NavHostFragment.findNavController(this)
                .navigate(R.id.action_signupFragment_to_googleSigninFragment);
    }
    private void navigateToHome() {
        NavHostFragment.findNavController(this)
                .navigate(R.id.action_signupFragment_to_chooseCityFragment);
    }
    private void navigateToSignin() {
        NavHostFragment.findNavController(this)
                .navigate(R.id.action_signupFragment_to_signinFragment);
    }
}