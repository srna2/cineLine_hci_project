package com.iman.cineline.home;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.iman.cineline.R;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class MovieChooseSeatFragment extends Fragment {

    private int number = 1;
    private int price = 0;
    private TextView numberTextView;
    private TextView priceTextView;
    private TextView totalTextView;
    private TextView descriptionView;

    private TextView title;
    private TextView type;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_movie_choose_seat, container, false);

        LocalDate currentDate = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd");
        String formattedDate = currentDate.format(formatter);
        TextView date = view.findViewById(R.id.date);
        date.setText(formattedDate);

        numberTextView = view.findViewById(R.id.number);
        priceTextView = view.findViewById(R.id.price);
        totalTextView = view.findViewById(R.id.total);
        descriptionView = view.findViewById(R.id.description);

        title = view.findViewById(R.id.title);
        type = view.findViewById(R.id.type);

        ImageView imageView = view.findViewById(R.id.image);


        SharedPreferences sharedPreferences = requireContext().getSharedPreferences("MoviePrefs", Context.MODE_PRIVATE);
        price = sharedPreferences.getInt("price", 0);
        descriptionView.setText(sharedPreferences.getString("opis",""));
        type.setText(sharedPreferences.getString("type",""));
        title.setText(sharedPreferences.getString("title",""));
        String imageUrl = sharedPreferences.getString("imageUrl", "");

        Glide.with(this)
                .load(imageUrl) // Add a placeholder image if desired
                .placeholder(R.drawable.movie_ticket)
                .into(imageView);

        updatePriceAndTotal();

        View incrementView = view.findViewById(R.id.increment);
        incrementView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number++;
                updatePriceAndTotal();
            }
        });

        View decrementView = view.findViewById(R.id.decrement);
        decrementView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (number > 1) {
                    number--;
                    updatePriceAndTotal();
                }
            }
        });

        Button continueButton = view.findViewById(R.id.nastavi);
        continueButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToMoviePaymentFragment();
            }
        });

        return view;
    }

    private void navigateToMoviePaymentFragment() {
        // Retrieve the NavController
        NavController navController = NavHostFragment.findNavController(this);

        // Navigate to the movie payment fragment using the action
        navController.navigate(R.id.action_movieChooseSeatFragment_to_moviePaymentFragment);
    }


    private void updatePriceAndTotal() {
        numberTextView.setText(String.valueOf(number));
        priceTextView.setText(String.valueOf(price));
        int total = number * price;
        totalTextView.setText(String.valueOf(total));
    }
}