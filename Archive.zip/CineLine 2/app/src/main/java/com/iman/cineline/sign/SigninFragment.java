package com.iman.cineline.sign;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.iman.cineline.R;

public class SigninFragment extends Fragment {


    private EditText emailEditText;
    private EditText passwordEditText;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_signin, container, false);

        emailEditText = view.findViewById(R.id.email);
        passwordEditText = view.findViewById(R.id.password);

        Button getStartedButton = view.findViewById(R.id.get_started);
        getStartedButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = emailEditText.getText().toString().trim();
                String password = passwordEditText.getText().toString().trim();
                if (email.equals("test@test.com") && password.equals("pass123")) {
                    navigateToChooseCityFragment();
                } else {
                    displayWarningToast();
                }
            }
        });

        return view;
    }

    private void navigateToChooseCityFragment() {
        NavHostFragment.findNavController(this)
                .navigate(R.id.action_signinFragment_to_chooseCityFragment);
    }

    private void displayWarningToast() {
        Toast.makeText(requireContext(), "Invalid email or password", Toast.LENGTH_SHORT).show();
    }
}