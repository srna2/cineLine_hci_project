package com.iman.cineline.onboarding;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.iman.cineline.R;

public class ChooseLoginFragment extends Fragment {


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_choose_login, container, false);

        View button3 = view.findViewById(R.id.button3);
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToSigninFragment();
            }
        });

        View signupButton = view.findViewById(R.id.signup);
        signupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToSignupFragment();
            }
        });

        View button2 = view.findViewById(R.id.button2);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateGoogle();
            }
        });

        return view;
    }

    private void navigateToSigninFragment() {
        NavHostFragment.findNavController(this)
                .navigate(R.id.action_chooseLoginFragment_to_signinFragment);
    }

    private void navigateToSignupFragment() {
        NavHostFragment.findNavController(this)
                .navigate(R.id.action_chooseLoginFragment_to_signupFragment);
    }

    private void navigateGoogle() {
        NavHostFragment.findNavController(this)
                .navigate(R.id.action_chooseLoginFragment_to_googleSigninFragment);
    }
}