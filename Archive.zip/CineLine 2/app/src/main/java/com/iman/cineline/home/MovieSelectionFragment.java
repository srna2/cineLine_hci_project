package com.iman.cineline.home;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.navigation.NavController;
import androidx.navigation.NavDirections;
import androidx.navigation.fragment.NavHostFragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.iman.cineline.R;
import com.iman.cineline.model.Movie;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class MovieSelectionFragment extends Fragment {

    private RecyclerView recyclerView;
    private MovieAdapter movieAdapter;
    private List<Movie> movieList;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_movie_selection, container, false);

        recyclerView = view.findViewById(R.id.recycler);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        LocalDate currentDate = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd");
        String formattedDate = currentDate.format(formatter);
        TextView date = view.findViewById(R.id.date);
        date.setText(formattedDate);

        movieList = new ArrayList<>();
        loadMoviesFromJson();

        movieAdapter = new MovieAdapter(movieList);
        recyclerView.setAdapter(movieAdapter);

        return view;
    }

    private void loadMoviesFromJson() {
        try {
            InputStream inputStream = getActivity().getAssets().open("movies.json");
            int size = inputStream.available();
            byte[] buffer = new byte[size];
            inputStream.read(buffer);
            inputStream.close();

            String json = new String(buffer, "UTF-8");

            JSONArray jsonArray = new JSONArray(json);
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                String title = jsonObject.getString("title");
                String subtitle = jsonObject.getString("opis");
                String imageUrl = jsonObject.getString("imageUrl");
                String type = jsonObject.getString("type");
                String redatelj = jsonObject.getString("redatelj");
                String pocetak = jsonObject.getString("pocetak");
                String trajanje = jsonObject.getString("trajanje");
                int price = jsonObject.getInt("price");

                Movie movie = new Movie(title,subtitle,imageUrl, type, redatelj, pocetak, trajanje, price);
                movieList.add(movie);
            }
        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }
    }

    private class MovieAdapter extends RecyclerView.Adapter<MovieAdapter.MovieViewHolder> {

        private List<Movie> movies;

        public MovieAdapter(List<Movie> movies) {
            this.movies = movies;
        }

        @NonNull
        @Override
        public MovieViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_movie, parent, false);
            return new MovieViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull MovieViewHolder holder, int position) {
            Movie movie = movies.get(position);
            holder.bind(movie);
        }

        @Override
        public int getItemCount() {
            return movies.size();
        }

        class MovieViewHolder extends RecyclerView.ViewHolder {

            private ImageView imageView;
            private TextView titleTextView;
            private TextView redatelj;
            private TextView trajanje;
            private TextView zanr;
            private TextView godina;

            public MovieViewHolder(@NonNull View itemView) {
                super(itemView);

                imageView = itemView.findViewById(R.id.image);
                titleTextView = itemView.findViewById(R.id.title);
                redatelj = itemView.findViewById(R.id.redatelj_text);
                trajanje = itemView.findViewById(R.id.trajanje_text);
                zanr = itemView.findViewById(R.id.zanr_text);
                godina = itemView.findViewById(R.id.godina_text);
            }

            public void bind(Movie movie) {
                // Load image using Glide
                Glide.with(itemView)
                        .load(movie.getImageUrl())
                        .placeholder(R.drawable.movie_ticket)
                        .into(imageView);

                titleTextView.setText(movie.getTitle());
                redatelj.setText(movie.getRedatelj());
                trajanje.setText(movie.getTrajanje());
                zanr.setText(movie.getType());
                godina.setText(movie.getPocetak());


                itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // Handle item click and navigate to the movie details fragment
                        Movie selectedMovie = movies.get(getAdapterPosition());
                        navigateToMovieDetailsFragment(selectedMovie);
                    }
                });
            }
        }
    }

    private void navigateToMovieDetailsFragment(Movie movie) {
        // Save movie details in SharedPreferences
        SharedPreferences sharedPreferences = requireContext().getSharedPreferences("MoviePrefs", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("title", movie.getTitle());
        editor.putString("opis", movie.getOpis());
        editor.putString("type", movie.getType());
        editor.putString("redatelj",movie.getRedatelj());
        editor.putString("trajanje",movie.getTrajanje());
        editor.putInt("price",movie.getPrice());
        editor.putString("pocetak",movie.getPocetak());
        editor.putString("imageUrl", movie.getImageUrl());
        editor.apply();

        // Navigate to the movie details fragment
        NavController navController = NavHostFragment.findNavController(this);
        navController.navigate(R.id.action_movieSelectionFragment_to_movieDetailsFragment);
    }
}