package com.iman.cineline.model;

public class Movie {
    private String title;
    private String opis;

    public void setTitle(String title) {
        this.title = title;
    }

    public void setOpis(String opis) {
        this.opis = opis;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setRedatelj(String redatelj) {
        this.redatelj = redatelj;
    }

    public void setPocetak(String pocetak) {
        this.pocetak = pocetak;
    }

    public void setTrajanje(String trajanje) {
        this.trajanje = trajanje;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    private String imageUrl;
    private String type;

    public String getTitle() {
        return title;
    }

    public String getOpis() {
        return opis;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public String getType() {
        return type;
    }

    public String getRedatelj() {
        return redatelj;
    }

    public String getPocetak() {
        return pocetak;
    }

    public String getTrajanje() {
        return trajanje;
    }

    public int getPrice() {
        return price;
    }

    private String redatelj;
    private String pocetak;
    private String trajanje;
    private int price;


    public Movie(String title, String opis, String imageUrl, String type, String redatelj, String pocetak, String trajanje, int price) {
        this.title = title;
        this.opis = opis;
        this.imageUrl = imageUrl;
        this.type = type;
        this.redatelj = redatelj;
        this.pocetak = pocetak;
        this.trajanje = trajanje;
        this.price = price;
    }

}
